#include <iostream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <climits>
#include <string>
#include <algorithm>

using namespace std;

typedef pair<int, string> Node;

class Graph {
private:
    unordered_map<string, vector<pair<string, int>>> adjacencyList;

public:
    void addEdge(const string& from, const string& to, int weight) {
        adjacencyList[from].emplace_back(to, weight);
        adjacencyList[to].emplace_back(from, weight); 
    }

    const unordered_map<string, vector<pair<string, int>>>& getGraph() const {
        return adjacencyList;
    }
};

class Dijkstra {
private:
    unordered_map<string, int> distances;
    unordered_map<string, string> previous;

public:
    void findShortestPath(const unordered_map<string, vector<pair<string, int>>>& graph,
                          const string& start) {
        if (graph.find(start) == graph.end()) {
            throw invalid_argument("Node awal tidak ditemukan dalam graf.");
        }

        for (const auto& node : graph) {
            distances[node.first] = INT_MAX;
        }
        distances[start] = 0;

        priority_queue<Node, vector<Node>, greater<Node>> priorityQueue;
        priorityQueue.push({0, start});

        while (!priorityQueue.empty()) {
            int currentDistance = priorityQueue.top().first;
            string currentNode = priorityQueue.top().second;
            priorityQueue.pop();

            if (currentDistance > distances[currentNode]) continue;

            for (const auto& neighbor : graph.at(currentNode)) {
                string nextNode = neighbor.first;
                int edgeWeight = neighbor.second;
                int newDistance = currentDistance + edgeWeight;

                if (newDistance < distances[nextNode]) {
                    distances[nextNode] = newDistance;
                    previous[nextNode] = currentNode;
                    priorityQueue.push({newDistance, nextNode});
                }
            }
        }
    }

    vector<string> getShortestPath(const string& start, const string& end) const {
        vector<string> path;
        if (distances.find(end) == distances.end() || distances.at(end) == INT_MAX) {
            return path;
        }

        for (string at = end; !at.empty(); at = previous.count(at) ? previous.at(at) : "") {
            path.push_back(at);
        }
        reverse(path.begin(), path.end());
        return path;
    }

    void printResults(const string& start, const string& end) const {
        vector<string> path = getShortestPath(start, end);
        if (path.empty()) {
            cout << "\nTidak ada jalur dari '" << start << "' ke '" << end << "'.\n";
            return;
        }

        cout << "\nJalur Terpendek dari '" << start << "' ke '" << end << "':\n";
        for (size_t i = 0; i < path.size(); ++i) {
            cout << path[i];
            if (i != path.size() - 1) cout << " -> ";
        }
        cout << "\nJarak Total: " << distances.at(end) << endl;
    }
};

bool isValidStation(const unordered_map<string, vector<pair<string, int>>>& graph, const string& station) {
    return graph.find(station) != graph.end();
}

int main() {
    Graph krlSolo, batikSoloTrans;

    krlSolo.addEdge("Solo Balapan", "Purwosari", 5);
    krlSolo.addEdge("Purwosari", "Gawok", 4);
    krlSolo.addEdge("Gawok", "Delanggu", 6);
    krlSolo.addEdge("Delanggu", "Ceper", 3);
    krlSolo.addEdge("Ceper", "Klaten", 7);
    krlSolo.addEdge("Klaten", "Srowot", 8);
    krlSolo.addEdge("Srowot", "Brambanan", 5);
    krlSolo.addEdge("Brambanan", "Maguwo", 4);
    krlSolo.addEdge("Maguwo", "Lempuyangan", 3);
    krlSolo.addEdge("Lempuyangan", "Yogyakarta", 5);

    batikSoloTrans.addEdge("Palur", "Bandara Adisumarmo", 10);
    batikSoloTrans.addEdge("Kartasura", "Palur", 12);
    batikSoloTrans.addEdge("Kartasura", "Palur", 12);
    batikSoloTrans.addEdge("Kartasura", "Solo Baru", 8);
    batikSoloTrans.addEdge("Mojosongo", "Solo Baru", 15);
    batikSoloTrans.addEdge("Kadipiro", "Semanggi", 9);
    batikSoloTrans.addEdge("Palur", "Solo Baru", 14);

    int choice;
    string startStation, endStation;

    cout << "Pilih Jenis Transportasi:\n";
    cout << "1. KRL Solo - Yogyakarta\n";
    cout << "2. Batik Solo Trans\n";
    cout << "Masukkan Pilihan Anda (1/2): ";
    cin >> choice;
    cin.ignore();

    if (choice == 1) {
        cout << "\n*** Selamat Datang di KRL Solo - Yogyakarta ***\n";
        cout << "Daftar Stasiun yang Tersedia:\n";
        cout << "- Solo Balapan\n- Purwosari\n- Gawok\n- Delanggu\n- Ceper\n- Klaten\n- Srowot\n- Brambanan\n- Maguwo\n- Lempuyangan\n- Yogyakarta\n";

        cout << "\nMasukkan Stasiun Awal: ";
        getline(cin, startStation);
        if (!isValidStation(krlSolo.getGraph(), startStation)) {
            cout << "Stasiun awal tidak valid.\n";
            return 1;
        }

        cout << "Masukkan Stasiun Akhir: ";
        getline(cin, endStation);
        if (!isValidStation(krlSolo.getGraph(), endStation)) {
            cout << "Stasiun akhir tidak valid.\n";
            return 1;
        }

        Dijkstra dijkstra;
        try {
            dijkstra.findShortestPath(krlSolo.getGraph(), startStation);
            dijkstra.printResults(startStation, endStation);
        } catch (const exception& e) {
            cerr << "Error: " << e.what() << endl;
        }
    } else if (choice == 2) {
        cout << "\n*** Selamat Datang di Batik Solo Trans ***\n";
        cout << "Daftar Koridor dan Terminal yang Tersedia:\n";
        cout << "Koridor 1: Palur - Bandara Adisumarmo\n";
        cout << "Koridor 2: Kartasura - Palur\n";
        cout << "Koridor 3: Kartasura - Palur\n";
        cout << "Koridor 4: Kartasura - Solo Baru\n";
        cout << "Koridor 5: Mojosongo - Solo Baru\n";
        cout << "Koridor 6: Kadipiro - Semanggi\n";
        cout << "Koridor 7: Palur - Solo Baru\n";

        cout << "\nMasukkan Terminal Awal: ";
        getline(cin, startStation);
        if (!isValidStation(batikSoloTrans.getGraph(), startStation)) {
            cout << "Terminal awal tidak valid.\n";
            return 1;
        }

        cout << "Masukkan Terminal Akhir: ";
        getline(cin, endStation);
        if (!isValidStation(batikSoloTrans.getGraph(), endStation)) {
            cout << "Terminal akhir tidak valid.\n";
            return 1;
        }

        Dijkstra dijkstra;
        try {
            dijkstra.findShortestPath(batikSoloTrans.getGraph(), startStation);
            dijkstra.printResults(startStation, endStation);
        } catch (const exception& e) {
            cerr << "Error: " << e.what() << endl;
        }
    } else {
        cout << "Pilihan tidak valid!\n";
    }

    return 0;
}

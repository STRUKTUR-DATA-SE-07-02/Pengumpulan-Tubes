#include <iostream>
#include <algorithm>
#include <vector>
#include <climits>
#include <string>
#include <map>
#include <set>
#include <fstream> // Untuk file I/O
#include <cstdlib> // Untuk system() function

using namespace std;

struct TransportOption {
    string mode;
    int time; // Waktu tempuh dalam menit
};

struct Edge {
    int destination;
    vector<TransportOption> options; // Daftar moda transportasi dengan waktu tempuh
};

class Graph {
private:
    map<int, vector<Edge>> adjacencyList;
    map<int, string> landmarks; // Menyimpan nama landmark berdasarkan ID

public:
    void addLandmark(int id, string name) {
        landmarks[id] = name;
    }

    void addEdge(int source, int destination, const string& mode, int time) {
        auto it = find_if(adjacencyList[source].begin(), adjacencyList[source].end(),
                          [destination](const Edge& e) { return e.destination == destination; });

        if (it != adjacencyList[source].end()) {
            it->options.push_back({mode, time});
        } else {
            Edge newEdge = {destination, {{mode, time}}};
            adjacencyList[source].push_back(newEdge);
        }

        it = find_if(adjacencyList[destination].begin(), adjacencyList[destination].end(),
                     [source](const Edge& e) { return e.destination == source; });

        if (it != adjacencyList[destination].end()) {
            it->options.push_back({mode, time});
        } else {
            Edge reverseEdge = {source, {{mode, time}}};
            adjacencyList[destination].push_back(reverseEdge);
        }
    }

    void showAllRoutes() {
        for (const auto& node : adjacencyList) {
            cout << "Landmark " << landmarks[node.first] << " -> \n";
            for (const auto& edge : node.second) {
                cout << "  Ke " << landmarks[edge.destination] << ":\n";
                for (const auto& option : edge.options) {
                    cout << "    - " << option.mode << " (Waktu: " << option.time << " menit)\n";
                }
            }
        }
    }

    void generateGraphviz(const string& filename) {
        ofstream file(filename);
        if (!file.is_open()) {
            cerr << "Gagal membuka file untuk menulis visualisasi Graphviz." << endl;
            return;
        }

        file << "digraph G {\n";
        file << "  rankdir=LR;\n";
        file << "  node [shape=circle];\n";

        for (const auto& node : adjacencyList) {
            for (const auto& edge : node.second) {
                for (const auto& option : edge.options) {
                    file << "  \"" << landmarks[node.first] << "\" -> \"" 
                         << landmarks[edge.destination] << "\" [label=\""
                         << option.mode << " (" << option.time << "m)\"];\n";
                }
            }
        }

        file << "}\n";
        file.close();

        // Jalankan perintah Graphviz secara otomatis
        string command = "dot -Tpng " + filename + " -o graphviz.png";
        int result = system(command.c_str());

        if (result == 0) {
            cout << "Graphviz telah dihasilkan dalam file: graphviz.png" << endl;
        } else {
            cerr << "Gagal menjalankan perintah Graphviz." << endl;
        }
    }

    void dijkstraFastest(int start, int end) {
        map<int, int> distances;
        map<int, int> previous;
        set<pair<int, int>> queue;

        for (const auto& node : adjacencyList) {
            distances[node.first] = INT_MAX;
        }
        distances[start] = 0;
        queue.insert({0, start});

        while (!queue.empty()) {
            int current = queue.begin()->second;
            queue.erase(queue.begin());

            if (current == end) break;

            for (const auto& edge : adjacencyList[current]) {
                for (const auto& option : edge.options) {
                    int neighbor = edge.destination;
                    int newDist = distances[current] + option.time;

                    if (newDist < distances[neighbor]) {
                        queue.erase({distances[neighbor], neighbor});
                        distances[neighbor] = newDist;
                        previous[neighbor] = current;
                        queue.insert({newDist, neighbor});
                    }
                }
            }
        }

        if (distances[end] == INT_MAX) {
            cout << "Tidak ada jalur dari " << landmarks[start] << " ke " << landmarks[end] << endl;
        } else {
            cout << "Waktu tercepat dari " << landmarks[start] << " ke " << landmarks[end] 
                 << " adalah " << distances[end] << " menit." << endl;

            vector<int> path;
            vector<string> modes;
            vector<int> times;
            for (int at = end; at != start; at = previous[at]) {
                path.push_back(at);
                for (const auto& edge : adjacencyList[previous[at]]) {
                    if (edge.destination == at) {
                        for (const auto& option : edge.options) {
                            if (distances[at] - option.time == distances[previous[at]]) {
                                modes.push_back(option.mode);
                                times.push_back(option.time);
                                break;
                            }
                        }
                        break;
                    }
                }
            }
            path.push_back(start);
            reverse(path.begin(), path.end());
            reverse(modes.begin(), modes.end());
            reverse(times.begin(), times.end());

            for (size_t i = 0; i < path.size(); ++i) {
                cout << landmarks[path[i]];
                if (i < path.size() - 1) {
                    cout << " (" << modes[i] << ") --" << times[i] << " menit--> ";
                }
            }
            cout << endl;
        }
    }

    void dijkstraWithPreference(int start, int end, const string& preferredMode) {
        map<int, int> distances;
        map<int, int> previous;
        set<pair<int, int>> queue;

        for (const auto& node : adjacencyList) {
            distances[node.first] = INT_MAX;
        }
        distances[start] = 0;
        queue.insert({0, start});

        while (!queue.empty()) {
            int current = queue.begin()->second;
            queue.erase(queue.begin());

            if (current == end) break;

            for (const auto& edge : adjacencyList[current]) {
                for (const auto& option : edge.options) {
                    if (option.mode != preferredMode) continue;

                    int neighbor = edge.destination;
                    int newDist = distances[current] + option.time;

                    if (newDist < distances[neighbor]) {
                        queue.erase({distances[neighbor], neighbor});
                        distances[neighbor] = newDist;
                        previous[neighbor] = current;
                        queue.insert({newDist, neighbor});
                    }
                }
            }
        }

        if (distances[end] == INT_MAX) {
            cout << "Tidak ada jalur dari " << landmarks[start] << " ke " << landmarks[end] 
                 << " menggunakan moda " << preferredMode << endl;
        } else {
            cout << "Waktu tercepat dari " << landmarks[start] << " ke " << landmarks[end] 
                 << " menggunakan moda " << preferredMode << " adalah " << distances[end] << " menit." << endl;

            vector<int> path;
            for (int at = end; at != 0; at = previous[at]) {
                path.push_back(at);
            }
            reverse(path.begin(), path.end());
            for (size_t i = 0; i < path.size(); ++i) {
                cout << landmarks[path[i]];
                if (i < path.size() - 1) cout << " -> ";
            }
            cout << endl;
        }
    }

    void reachableNodes(int start) {
        set<int> visited;
        vector<int> stack = {start};

        cout << "Landmark yang dapat dicapai dari " << landmarks[start] << ":" << endl;

        while (!stack.empty()) {
            int current = stack.back();
            stack.pop_back();

            if (visited.find(current) == visited.end()) {
                visited.insert(current);
                cout << "- " << landmarks[current] << endl;

                for (const auto& edge : adjacencyList[current]) {
                    stack.push_back(edge.destination);
                }
            }
        }
    }
};

int main() {
    Graph g;

    // Menambahkan landmark di Jakarta
    g.addLandmark(1, "Monumen Nasional (Monas)");
    g.addLandmark(2, "Stasiun Gambir");
    g.addLandmark(3, "Bundaran HI");
    g.addLandmark(4, "Kota Tua Jakarta");
    g.addLandmark(5, "Taman Mini Indonesia Indah (TMII)");

    // Menambahkan rute manual (waktu dalam menit)
    g.addEdge(1, 2, "Jalan Kaki", 15);
    g.addEdge(1, 3, "Bus", 25);
    g.addEdge(1, 3, "Taxi", 20);
    g.addEdge(2, 3, "Kereta", 10);
    g.addEdge(2, 4, "Bus", 35);
    g.addEdge(3, 4, "MRT", 20);
    g.addEdge(3, 5, "Bus", 50);
    g.addEdge(3, 5, "Taxi", 40);
    g.addEdge(4, 5, "Kereta", 45);

    // Output semua rute
    cout << "--- Semua Rute ---" << endl;
    g.showAllRoutes();

    // Visualisasi Graphviz
    // g.generateGraphviz("graph.dot");

    // Algoritma Dijkstra untuk waktu tercepat
    cout << "\n--- Dijkstra (Moda Tercepat) ---" << endl;
    g.dijkstraFastest(1, 5);

    // Algoritma Dijkstra dengan preferensi moda transportasi
    cout << "\n--- Dijkstra dengan Preferensi (Jalan Kaki) ---" << endl;
    g.dijkstraWithPreference(1, 5, "Jalan Kaki");

    g.reachableNodes(1);

    return 0;
}
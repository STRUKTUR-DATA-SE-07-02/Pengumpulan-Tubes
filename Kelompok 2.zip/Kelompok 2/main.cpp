#include <iostream>
#include <vector>
#include <unordered_map>
#include <string>
#include <fstream>
#include <iomanip> // Untuk setw
#include <cstdlib> // Untuk system()

using namespace std;

class SocialNetwork {
private:
    unordered_map<string, int> userIndex; // Pemetaan nama pengguna ke indeks
    vector<vector<int>> adjMatrix;       // Matriks adjacency untuk menyimpan frekuensi interaksi
    vector<string> users;                // Daftar nama pengguna

    // Memeriksa apakah Graphviz tersedia
    bool isGraphvizAvailable() {
        return system("dot -V >nul 2>&1") == 0;
    }


public:
    // Menambahkan pengguna ke jaringan dan mengupdate indeks mereka
    void addUser(const string& user) {
        if (userIndex.find(user) == userIndex.end()) {
            userIndex[user] = users.size();
            users.push_back(user);
            // Memperluas matriks dengan ukuran baru
            for (auto& row : adjMatrix) {
                row.push_back(0);
            }
            adjMatrix.push_back(vector<int>(users.size(), 0));
        }
    }

    // Menambahkan hubungan pertemanan antara dua pengguna
    void addFriendship(const string& user1, const string& user2, int frequency) {
        addUser(user1);
        addUser(user2);
        int i = userIndex[user1];
        int j = userIndex[user2];
        adjMatrix[i][j] = frequency;
        adjMatrix[j][i] = frequency; // Karena pertemanan bersifat dua arah
    }

    // Menampilkan matriks adjacency dengan format rapi
    void displayAdjMatrix() {
        cout << "Adjacency Matrix:\n";
        cout << "         ";

        // Menampilkan nama pengguna di bagian atas matriks
        for (const auto& user : users) {
            cout << setw(8) << user; // Mengatur lebar kolom agar rapi
        }
        cout << endl;

        // Menampilkan isi matriks dengan nilai-nilai frekuensi interaksi
        for (size_t i = 0; i < adjMatrix.size(); ++i) {
            cout << setw(8) << users[i]; // Menampilkan nama pengguna di sebelah kiri
            for (size_t j = 0; j < adjMatrix[i].size(); ++j) {
                cout << setw(8) << adjMatrix[i][j];
            }
            cout << endl;
        }
    }

    void exportToGraphviz(const string& filename) {
        ofstream file(filename);
        if (!file.is_open()) {
            cerr << "Gagal membuka file " << filename << endl;
        return;
        }

        file << "graph SocialNetwork {" << endl;
        file << "  node [shape=circle, style=filled, color=lightblue, fontname=\"Helvetica\"];" << endl;
        file << "  edge [fontname=\"Helvetica\"];" << endl;

        // Menambahkan simpul (nodes) ke file .dot
        for (const string& user : users) {
            file << "  \"" << user << "\";" << endl;
        }

        // Menambahkan sisi (edges) ke file .dot
        for (size_t i = 0; i < adjMatrix.size(); ++i) {
            for (size_t j = i + 1; j < adjMatrix[i].size(); ++j) {
                if (adjMatrix[i][j] > 0) {
                    file << "  \"" << users[i] << "\" -- \"" << users[j]
                         << "\" [label=\"" << adjMatrix[i][j] << "\"];" << endl;
                }
            }
        }

        file << "}" << endl;
        file.close();
        cout << "Graf telah diekspor ke " << filename << endl;

        // Mengecek apakah Graphviz tersedia di sistem
        if (system("dot -V >nul 2>&1") != 0) {
            cerr << "Graphviz tidak ditemukan di sistem Anda. Pastikan Graphviz terinstal." << endl;
            return;
        }

        // Menjalankan perintah Graphviz untuk menghasilkan gambar PNG
        string command = "dot -Tpng " + filename + " -o " + filename + ".png";
        int result = system(command.c_str());
        if (result != 0) {
            cerr << "Perintah Graphviz gagal dijalankan!" << endl;
            return;
            }
            cout << "Gambar PNG telah dibuat: " << filename << ".png" << endl;
    }


        // Menyimpan adjacency matrix ke file
    void saveAdjMatrixToFile(const string& filename) {
        ofstream file(filename);
        if (!file.is_open()) {
            cerr << "Gagal membuka file " << filename << endl;
            return;
        }

        file << "Adjacency Matrix:\n";
        file << "         ";

        for (const auto& user : users) {
            file << setw(8) << user;
        }
        file << endl;

        for (size_t i = 0; i < adjMatrix.size(); ++i) {
            file << setw(8) << users[i];
            for (size_t j = 0; j < adjMatrix[i].size(); ++j) {
                file << setw(8) << adjMatrix[i][j];
            }
            file << endl;
        }
        file.close();
        cout << "Adjacency Matrix telah disimpan ke file " << filename << endl;
    }
};

int main() {
    SocialNetwork sn;

    // Menambahkan beberapa hubungan pertemanan
    sn.addFriendship("Alice", "Bob", 15);
    sn.addFriendship("Alice", "Charlie", 4);
    sn.addFriendship("Bob", "David", 8);
    sn.addFriendship("Charlie", "David", 5);
    sn.addFriendship("David", "Eve", 6);
    sn.addFriendship("Eve", "Frank", 3);
    sn.addFriendship("Alice", "Frank", 7);

    // Menampilkan matriks adjacency dengan format rapi
    sn.displayAdjMatrix();

    // Mengekspor graf ke file .dot dan menghasilkan file .png
    sn.exportToGraphviz("social_network.dot");

    return 0; // Tambahkan return 0 untuk memastikan fungsi main selesai dengan benar
}

#include <iostream>
#include <vector>
#include <queue>
#include <climits>
#include <string>

using namespace std;

class Graph {
public:
    int V; // Jumlah vertex
    vector<vector<pair<int, int>>> adj; // Adjacency list (node, weight)
    vector<string> cities; // Nama kota

    Graph(int V) {
        this->V = V;
        adj.resize(V);
        cities.resize(V);
    }

    void addCity(int index, const string& name) {
        cities[index] = name;
    }

    void addEdge(int u, int v, int w) {
        adj[u].push_back(make_pair(v, w));
        adj[v].push_back(make_pair(u, w)); // Karena graf tidak terarah
    }

    void dijkstra(int src) {
        vector<int> dist(V, INT_MAX);
        vector<int> parent(V, -1);
        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;

        dist[src] = 0;
        pq.push(make_pair(0, src));

        while (!pq.empty()) {
            int u = pq.top().second;
            pq.pop();

            for (auto& neighbor : adj[u]) {
                int v = neighbor.first;
                int weight = neighbor.second;

                if (dist[u] + weight < dist[v]) {
                    dist[v] = dist[u] + weight;
                    parent[v] = u;
                    pq.push(make_pair(dist[v], v));
                }
            }
        }

        printPath(parent, src);
    }

    void printPath(vector<int>& parent, int src) {
        cout << "Rute terpendek melewati: ";
        vector<int> path;
        for (int v = 0; v < V; v++) {
            if (parent[v] != -1 || v == src) {
                path.push_back(v);
            }
        }
        for (int i = 0; i < path.size(); i++) {
            cout << cities[path[i]];
            if (i < path.size() - 1) {
                cout << " -> ";
            }
        }
        cout << endl;
    }

    void printWeights() {
        cout << "\nBobot antar node (jarak fiktif dalam satuan tertentu):" << endl;
        for (int u = 0; u < V; u++) {
            for (auto& neighbor : adj[u]) {
                int v = neighbor.first;
                int weight = neighbor.second;
                if (u < v) { // Mencetak setiap edge hanya sekali
                    cout << cities[u] << " -> " << cities[v] << ": " << weight << endl;
                }
            }
        }
    }
};

int main() {
    // Kereta Api Semarang ke Surabaya
    Graph kereta(9); // 8 nodes + 1 for Surabaya
    kereta.addCity(0, "Semarang Tawang");
    kereta.addCity(1, "Ngrombo");
    kereta.addCity(2, "Kradenan");
    kereta.addCity(3, "Randublatung");
    kereta.addCity(4, "Cepu");
    kereta.addCity(5, "Bojonegoro");
    kereta.addCity(6, "Babat");
    kereta.addCity(7, "Lamongan");
    kereta.addCity(8, "Surabaya Pasar Turi");

    kereta.addEdge(0, 1, 30); // Semarang Tawang -> Ngrombo
    kereta.addEdge(1, 2, 20); // Ngrombo -> Kradenan
    kereta.addEdge(2, 3, 25); // Kradenan -> Randublatung
    kereta.addEdge(3, 4, 15); // Randublatung -> Cepu
    kereta.addEdge(4, 5, 35); // Cepu -> Bojonegoro
    kereta.addEdge(5, 6, 40); // Bojonegoro -> Babat
    kereta.addEdge(6, 7, 30); // Babat -> Lamongan
    kereta.addEdge(7, 8, 50); // Lamongan -> Surabaya Pasar Turi

    cout << "Kereta Api Semarang ke Surabaya:" << endl;
    kereta.dijkstra(0); // 0 adalah indeks Semarang Tawang
    kereta.printWeights(); // Menampilkan bobot antar node

    cout << endl; // Menambahkan spasi antara output

    // Bus Sugeng Rahayu Semarang ke Surabaya
    Graph bus(13); // 12 nodes + 1 for Surabaya
    bus.addCity(0, "Semarang");
    bus.addCity(1, "Ungaran");
    bus.addCity(2, "Salatiga");
    bus.addCity(3, "Boyolali");
    bus.addCity(4, "Kartasura");
    bus.addCity(5, "Solo");
    bus.addCity(6, "Sragen");
    bus.addCity(7, "Ngawi");
    bus.addCity(8, "Madiun");
    bus.addCity(9, "Nganjuk");
    bus.addCity(10, "Jombang");
    bus.addCity(11, "Mojokerto");
    bus.addCity(12, "Surabaya");

    bus.addEdge(0, 1, 10); // Semarang -> Ungaran
    bus.addEdge(1, 2, 20); // Ungaran -> Salatiga
    bus.addEdge(2, 3, 25); // Salatiga -> Boyolali
    bus.addEdge(3, 4, 15); // Boyolali -> Kartasura
    bus.addEdge(4, 5, 10); // Kartasura -> Solo
    bus.addEdge(5, 6, 35); // Solo -> Sragen
    bus.addEdge(6, 7, 30); // Sragen -> Ngawi
    bus.addEdge(7, 8, 40); // Ngawi -> Madiun
    bus.addEdge(8, 9, 20); // Madiun -> Nganjuk
    bus.addEdge(9, 10, 25); // Nganjuk -> Jombang
    bus.addEdge(10, 11, 15); // Jombang -> Mojokerto
    bus.addEdge(11, 12, 50); // Mojokerto -> Surabaya

    cout << "Bus Sugeng Rahayu Semarang ke Surabaya:" << endl;
    bus.dijkstra(0); // 0 adalah indeks Semarang
    bus.printWeights(); // Menampilkan bobot antar node

    return 0;
}

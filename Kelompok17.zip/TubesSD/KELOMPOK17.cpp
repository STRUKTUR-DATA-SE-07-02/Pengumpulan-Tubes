#include <iostream>
#include <vector>
#include <queue>
#include <climits>
#include <string>
#include <algorithm>

using namespace std;

// Struktur untuk merepresentasikan edge
struct Edge {
    int destination; // Tujuan edge
    int weight; // Berat edge atau jarak antara node
};

// Fungsi Dijkstra untuk mencari jalur terpendek
void dijkstra(int start, vector<vector<Edge>> &graph, vector<int> &dist, vector<int> &prev) {
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq; // Min-heap
    dist[start] = 0;
    pq.push({0, start});

    while (!pq.empty()) {
        int currentDistance = pq.top().first;
        int currentNode = pq.top().second;
        pq.pop();

        if (currentDistance > dist[currentNode]) {
            continue;
        }

        for (Edge &edge : graph[currentNode]) {
            int nextNode = edge.destination;
            int weight = edge.weight;

            if (dist[currentNode] + weight < dist[nextNode]) {
                dist[nextNode] = dist[currentNode] + weight;
                prev[nextNode] = currentNode;
                pq.push({dist[nextNode], nextNode});
            }
        }
    }
}

// Fungsi untuk mencetak jalur terpendek
void printPath(int node, vector<int> &prev, vector<string> &nodeNames) {
    if (node == -1) return;

    vector<int> path;
    while (node != -1) {
        path.push_back(node);
        node = prev[node];
    }

    reverse(path.begin(), path.end());

    for (size_t i = 0; i < path.size(); ++i) {
        cout << nodeNames[path[i]];
        if (i < path.size() - 1) {
            cout << " -> ";
        }
    }
}

int main() {
    const int numNodes = 6; //menyatakan jumlah node dalam grafnya
    vector<vector<Edge>> graph(numNodes); // vektor dua dimensi, baris pertama menyimpan daftar Egde untuk node pertama begitu juga seterusnya
    vector<string> nodeNames = { //sebuah vektor string yang berisi nama-nama lokasi yang sesuai dengan setiap node di graf.
        "Telkom University Landmark",   
        "Telkom University Aula Konvensi",
        "Fakultas Komunikasi dan Ilmu Sosial Telkom University",
        "Gedung Tokong Nanas Telkom University",
        "Gedung Rektorat Telkom University",
        "Gedung Damar (K) Telkom University"
    };

    graph[0].push_back({1, 500}); // Telkom University Landmark -> Telkom University Aula Konvensi 
    graph[0].push_back({3, 650}); // Telkom University Landmark -> Gedung Tokong Nanas Telkom University
    graph[1].push_back({0, 500}); // Telkom university Aula Konvensi -> Telkom University Landmark
    graph[1].push_back({2, 220}); // Telkom University Aula Konvensi -> Fakultas Komunikasi dan ilmu Sosial Telkom University
    graph[1].push_back({3, 500}); // Telkom University Aula Konvensi -> Gedung Tokong Nanas Telkom University
    graph[2].push_back({1, 220}); // Fakultas Komunikasi dan ilmu Sosial Telkom University -> Telkom University Aula Konvensi
    graph[2].push_back({4, 500}); // Fakultas Komunikasi dan ilmu Sosial Telkkom University -> Gedung Rektorat Telkom University
    graph[3].push_back({0, 650}); // Gedung Tokong Nanas Telkom University -> Telkom University Landmark
    graph[3].push_back({1, 500}); // Gedung Tokong Nanas Telkom University -> Telkom University Aula Konvensi
    graph[3].push_back({4, 190}); // Gedung Tokong Nanas Telkom University -> Gedung Rektorat Telkom University
    graph[3].push_back({5, 210}); // Gedung Tokong Nanas Telkom University -> Gedung Damar (K) Telkom University
    graph[4].push_back({2, 500}); // Gedung Rektorat Telkom University -> Fakultas Komunikasi dna Ilmu Sosial Telekom University
    graph[4].push_back({3, 190}); // Gedung Rektorat Telkom University -> Gedung Tokong Nanas Telkom University
    graph[4].push_back({5, 210}); // Gedung Rektorat Telkom University -> Gedung Damar (K) Telkom University
    graph[5].push_back({3, 210}); // Gedung Damar (K) Telkom University -> Gedung Tokong Nanas Telkom University
    graph[5].push_back({4, 210}); // Gedung Damar (K) Telkom University -> Gedung Rektorat Telkom University


    vector<int> dist(numNodes, INT_MAX);
    vector<int> prev(numNodes, -1);

    int startNode = 0;
    dijkstra(startNode, graph, dist, prev);

    cout << "Jarak dan jalur terpendek dari " << nodeNames[startNode] << ":\n\n";
    for (int i = 0; i < numNodes; ++i) {
        cout << "Ke " << nodeNames[i] << ": ";
        if (dist[i] == INT_MAX) {
            cout << "Tidak dapat dijangkau\n";
        } else {
            cout << dist[i] << " meter\n";
            cout << "Jalur: ";
            printPath(i, prev, nodeNames);
            cout << "\n";
        }
        cout << "\n";
    }

    return 0;
}
#include <iostream>
#include <vector>// menyimpan daftar stasiun atau terminal
#include <queue>
#include <limits>
#include <string>
#include <algorithm>
#include <fstream>
#include <unordered_map> //  efisiensi pencarian nama node
using namespace std;

// Struktur untuk menyimpan data node (stasiun atau terminal)
struct Node {
    string nama;  // Nama stasiun atau terminal
    string tipe;  // Jenis moda transportasi ("KERETA" atau "BUS")
    vector<pair<int, int>> tetangga; // Daftar tetangga dan bobot waktu tempuh
};

// Kelas untuk mengelola jaringan transportasi
class JaringanTransportasi {
private:
    vector<Node> nodes;  // Daftar semua node (stasiun atau terminal)
    unordered_map<string, int> namaToIndex; // Peta nama ke indeks node
    int jumlahNode;  // Jumlah total node dalam jaringan

public:
    // Konstruktor untuk inisialisasi jumlah node menjadi 0
    JaringanTransportasi() {
        jumlahNode = 0;
    }

    // Fungsi untuk menambahkan node (stasiun atau terminal)
    void tambahNode(string nama, string tipe) {
        if (namaToIndex.find(nama) != namaToIndex.end()) {
            cout << "Node dengan nama \"" << nama << "\" sudah ada!" << endl;
            return;
        }
        Node nodeBaru;
        nodeBaru.nama = nama;
        nodeBaru.tipe = tipe;
        nodes.push_back(nodeBaru);
        namaToIndex[nama] = jumlahNode;
        jumlahNode++;
    }

    // Fungsi untuk menambahkan rute (koneksi) antar node
    void tambahRute(int dari, int ke, int bobot) {
        if (dari >= 0 && dari < jumlahNode && ke >= 0 && ke < jumlahNode) {
            nodes[dari].tetangga.push_back({ke, bobot});
            nodes[ke].tetangga.push_back({dari, bobot});
        }
    }

    // Fungsi untuk mencari jalur terpendek menggunakan algoritma Dijkstra
    vector<int> cariJalurTerpendek(int awal, int akhir) {
        vector<int> jarak(jumlahNode, numeric_limits<int>::max());  // Inisialisasi jarak dengan nilai tak terhingga
        vector<int> sebelumnya(jumlahNode, -1);  // Menyimpan node sebelumnya pada jalur terpendek
        vector<bool> dikunjungi(jumlahNode, false);  // Status apakah node sudah dikunjungi

        jarak[awal] = 0;
        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
        pq.push({0, awal});  // Menambahkan node awal ke dalam priority queue

        while (!pq.empty()) {
            int u = pq.top().second;
            pq.pop();

            if (dikunjungi[u]) continue;
            dikunjungi[u] = true;

            for (const auto& tetangga : nodes[u].tetangga) {
                int v = tetangga.first;
                int bobot = tetangga.second;

                // Jika jarak ke tetangga lebih pendek melalui node u, update jarak dan tambahkan ke queue
                if (!dikunjungi[v] && jarak[u] + bobot < jarak[v]) {
                    jarak[v] = jarak[u] + bobot;
                    sebelumnya[v] = u;
                    pq.push({jarak[v], v});
                }
            }
        }

        // Membangun jalur terpendek berdasarkan informasi sebelumnya
        vector<int> jalur;
        for (int at = akhir; at != -1; at = sebelumnya[at]) {
            jalur.push_back(at);
        }
        reverse(jalur.begin(), jalur.end());  // Membalik jalur agar urut dari awal ke akhir

        return jalur;
    }

    // Fungsi untuk mencetak jalur terpendek
    void cetakJalur(const vector<int>& jalur) {
        if (jalur.empty()) {
            cout << "Tidak ditemukan jalur!" << endl;
            return;
        }

        int totalJarak = 0;
        string modaSebelumnya = "";

        for (size_t i = 0; i < jalur.size(); i++) {
            string modaSekarang = nodes[jalur[i]].tipe;

            // Menampilkan informasi saat pindah moda transportasi
            if (i > 0 && modaSekarang != modaSebelumnya) {
                cout << "\n[Pindah dari " << modaSebelumnya << " ke " << modaSekarang << "]\n";
            }

            cout << nodes[jalur[i]].nama << " (" << nodes[jalur[i]].tipe << ")";

            // Menampilkan waktu tempuh antar node
            if (i < jalur.size() - 1) {
                for (const auto& tetangga : nodes[jalur[i]].tetangga) {
                    if (tetangga.first == jalur[i + 1]) {
                        totalJarak += tetangga.second;
                        cout << " --(" << tetangga.second << " menit)--> ";
                        break;
                    }
                }
            }
            modaSebelumnya = modaSekarang;
        }
        cout << "\nTotal waktu tempuh: " << totalJarak << " menit" << endl;
    }

    // Fungsi untuk mencari rute dari stasiun atau terminal asal ke tujuan
    void cariSemuaRute(string dari, string ke) {
        if (namaToIndex.find(dari) == namaToIndex.end() || namaToIndex.find(ke) == namaToIndex.end()) {
            cout << "Stasiun atau terminal tidak ditemukan!" << endl;
            return;
        }

        int indexDari = namaToIndex[dari];
        int indexKe = namaToIndex[ke];

        cout << "\nMencari rute dari " << dari << " ke " << ke << ":\n" << endl;
        vector<int> jalurTerpendek = cariJalurTerpendek(indexDari, indexKe);
        cout << "Rute tercepat:" << endl;
        cetakJalur(jalurTerpendek);
    }

    // Fungsi untuk menghasilkan file Graphviz dan gambar visualisasi jaringan transportasi
    void generateGraphviz(const string& filename) {
        ofstream file(filename);
        if (!file) {
            cerr << "Gagal membuka file " << filename << endl;
            return;
        }

        // Menulis file Graphviz untuk menggambarkan jaringan transportasi
        file << "graph Transportasi {\n";  // "graph" karena kita menggunakan graf tak berarah
        file << "    node [shape=ellipse];\n";  // Bentuk node elips

        // Menulis semua node ke dalam file Graphviz
        for (size_t i = 0; i < nodes.size(); ++i) {
            file << "    " << i << " [label=\"" << nodes[i].nama << " (" << nodes[i].tipe << ")\"];\n";
        }

        // Menulis semua koneksi (edges) antar node ke dalam file Graphviz
        for (size_t i = 0; i < nodes.size(); ++i) {
            for (const auto& tetangga : nodes[i].tetangga) {
                if (i < tetangga.first) {  // Menghindari duplikasi edges
                    file << "    " << i << " -- " << tetangga.first
                         << " [label=\"" << tetangga.second << " menit\"];\n";
                }
            }
        }

        file << "}" << endl;
        file.close();

        cout << "File Graphviz berhasil dibuat: " << filename << endl;

        // Menggunakan Graphviz untuk mengonversi file .dot menjadi gambar .png
        string command = "dot -Tpng " + filename + " -o " + filename + ".png";
        system(command.c_str());

        // Membuka gambar hasil generate Graphviz
        string openCommand = "start " + filename + ".png";
        system(openCommand.c_str());
    }
};

int main() {
    JaringanTransportasi jaringan;

    // Menambahkan stasiun kereta
    jaringan.tambahNode("Stasiun Purwokerto", "KERETA");
    jaringan.tambahNode("Stasiun Notog", "KERETA");
    jaringan.tambahNode("Stasiun Kroya", "KERETA");
    jaringan.tambahNode("Stasiun Kemranjen", "KERETA");

    // Menambahkan terminal bus
    jaringan.tambahNode("Terminal Bulupitu", "BUS");
    jaringan.tambahNode("Terminal Ajibarang", "BUS");
    jaringan.tambahNode("Terminal Kebasen", "BUS");
    jaringan.tambahNode("Terminal Wangon", "BUS");

    // Menambahkan rute antar stasiun kereta
    jaringan.tambahRute(0, 1, 40);
    jaringan.tambahRute(1, 2, 40);
    jaringan.tambahRute(2, 3, 50);

    // Menambahkan rute antar terminal bus
    jaringan.tambahRute(4, 5, 45);
    jaringan.tambahRute(6, 7, 25);

    // Menambahkan rute integrasi antar moda transportasi (kereta dan bus)
    jaringan.tambahRute(1, 4, 45);
    jaringan.tambahRute(3, 6, 25);

    cout << "=== Sistem Informasi Rute Transportasi Terintegrasi ===" << endl;
    cout << "Mencakup: Kereta dan Bus" << endl << endl;

    string asal, tujuan;
    // Meminta input nama stasiun atau terminal asal dan tujuan
    cout << "Masukkan nama stasiun atau terminal asal: ";
    getline(cin, asal);
    while (asal.empty()) {
        cout << "Nama asal tidak boleh kosong! Masukkan kembali: ";
        getline(cin, asal);
    }

    cout << "Masukkan nama stasiun atau terminal tujuan: ";
    getline(cin, tujuan);
    while (tujuan.empty()) {
        cout << "Nama tujuan tidak boleh kosong! Masukkan kembali: ";
        getline(cin, tujuan);
    }

    // Mencari dan mencetak rute dari asal ke tujuan
    jaringan.cariSemuaRute(asal, tujuan);

    // Menghasilkan file Graphviz untuk visualisasi jaringan transportasi
    jaringan.generateGraphviz("transportasi.dot");

    return 0;
}

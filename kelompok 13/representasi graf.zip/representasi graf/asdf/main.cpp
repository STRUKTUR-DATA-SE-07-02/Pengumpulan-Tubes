#include <iostream>
#include <vector>
#include <map>
#include <string>
using namespace std;

void printAdjacencyList(map<string, vector<pair<string, int>>>& graph) {
    cout << "Adjacency List:" << endl;
    for (auto& node : graph) {
        cout << node.first << " -> ";
        for (auto& neighbor : node.second) {
            cout << "(" << neighbor.first << ", " << neighbor.second << ") ";
        }
        cout << endl;
    }
}

void printAdjacencyMatrix(map<string, vector<pair<string, int>>>& graph, vector<string>& nodes) {
    cout << "\nAdjacency Matrix:" << endl;

    cout << "      ";
    for (const auto& node : nodes) {
        cout << node << "\t";
    }
    cout << endl;

    for (const auto& node : nodes) {
        cout << node << "\t";
        for (const auto& target : nodes) {
            bool found = false;
            for (const auto& neighbor : graph[node]) {
                if (neighbor.first == target) {
                    cout << neighbor.second << "\t";
                    found = true;
                    break;
                }
            }
            if (!found) {
                cout << "0\t";
            }
        }
        cout << endl;
    }
}

int main() {
    vector<string> nodes = {"PKU", "PLM", "KNO", "CGK", "SRG", "SUB", "DPS", "UPG"};

    map<string, vector<pair<string, int>>> graph;

    graph["PKU"].push_back({"KNO", 60});
    graph["PKU"].push_back({"PLM", 90});
    graph["PKU"].push_back({"CGK", 120});
    graph["KNO"].push_back({"CGK", 105});
    graph["KNO"].push_back({"PLM", 75});
    graph["PLM"].push_back({"CGK", 95});
    graph["PLM"].push_back({"SUB", 100});
    graph["CGK"].push_back({"SRG", 60});
    graph["CGK"].push_back({"SUB", 90});
    graph["CGK"].push_back({"DPS", 120});
    graph["SRG"].push_back({"SUB", 90});
    graph["SRG"].push_back({"DPS", 90});
    graph["SUB"].push_back({"DPS", 60});
    graph["SUB"].push_back({"UPG", 150});
    graph["DPS"].push_back({"UPG", 120});


    printAdjacencyList(graph);

    printAdjacencyMatrix(graph, nodes);

    return 0;
}

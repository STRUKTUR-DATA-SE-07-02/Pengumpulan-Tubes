#include <iostream>
#include <queue>

using namespace std;

struct ElmNode;

struct ElmEdge {
    ElmNode *Node;
    ElmEdge *Next;
};

struct ElmNode {
    char info;
    bool visited;
    ElmEdge *firstEdge;
    ElmNode *Next;
};

struct Graph {
    ElmNode *first;
};

void CreateGraph(Graph &G) {
    G.first = nullptr;
}

void InsertNode(Graph &G, char X) {
    ElmNode *newNode = new ElmNode;
    newNode->info = X;
    newNode->visited = false;
    newNode->firstEdge = nullptr;
    newNode->Next = nullptr;

    if (G.first == nullptr) {
        G.first = newNode;
    } else {
        ElmNode *temp = G.first;
        while (temp->Next != nullptr) {
            temp = temp->Next;
        }
        temp->Next = newNode;
    }
}

void ConnectNode(ElmNode *N1, ElmNode *N2) {
    ElmEdge *newEdge = new ElmEdge;
    newEdge->Node = N2;
    newEdge->Next = N1->firstEdge;
    N1->firstEdge = newEdge;
}

void ResetVisited(Graph &G) {
    ElmNode *temp = G.first;
    while (temp != nullptr) {
        temp->visited = false;
        temp = temp->Next;
    }
}

void PrintDFS(Graph &G, ElmNode *N) {
    if (N == nullptr) {
        return;
    }
    N->visited = true;
    cout << N->info << " ";
    ElmEdge *edge = N->firstEdge;
    while (edge != nullptr) {
        if (!edge->Node->visited) {
            PrintDFS(G, edge->Node);
        }
        edge = edge->Next;
    }
}

void PrintBFS(Graph &G, ElmNode *N) {
    queue<ElmNode *> q;
    q.push(N);
    N->visited = true;

    while (!q.empty()) {
        ElmNode *current = q.front();
        q.pop();
        cout << current->info << " ";

        ElmEdge *edge = current->firstEdge;
        while (edge != nullptr) {
            if (!edge->Node->visited) {
                edge->Node->visited = true;
                q.push(edge->Node);
            }
            edge = edge->Next;
        }
    }
}

int main() {
    Graph G;
    CreateGraph(G);

    // Tambahkan node ke graf
    InsertNode(G, 'P');
    InsertNode(G, 'M');
    InsertNode(G, 'L');
    InsertNode(G, 'J');
    InsertNode(G, 'S');
    InsertNode(G, 'U');
    InsertNode(G, 'D');
    InsertNode(G, 'K');

    // Ambil referensi node
    ElmNode *P = G.first;
    ElmNode *M = P->Next;
    ElmNode *L = M->Next;
    ElmNode *J = L->Next;
    ElmNode *S = J->Next;
    ElmNode *U = S->Next;
    ElmNode *D = U->Next;
    ElmNode *K = D->Next;

    // Hubungkan node
    ConnectNode(P, M);
    ConnectNode(P, L);
    ConnectNode(P, J);
    ConnectNode(M, J);
    ConnectNode(M, L);
    ConnectNode(L, J);
    ConnectNode(L, U);
    ConnectNode(J, S);
    ConnectNode(J, U);
    ConnectNode(J, D);
    ConnectNode(S, U);
    ConnectNode(S, D);
    ConnectNode(U, D);
    ConnectNode(U, K);
    ConnectNode(D, K);

    // DFS traversal
    cout << "DFS Traversal: ";
    ResetVisited(G);
    PrintDFS(G, P);
    cout << endl;

    // BFS traversal
    cout << "BFS Traversal: ";
    ResetVisited(G);
    PrintBFS(G, P);
    cout << endl;

    return 0;
}

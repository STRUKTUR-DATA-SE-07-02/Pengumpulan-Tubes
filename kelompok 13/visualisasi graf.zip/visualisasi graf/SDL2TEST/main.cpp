#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <iostream>
#include <vector>
#include <cmath>

const int SCREEN_WIDTH = 800;
const int SCREEN_HEIGHT = 600;
const int NODE_RADIUS = 30;
const SDL_Color NODE_COLOR = {173, 216, 230, 255}; // Light Blue
const SDL_Color EDGE_COLOR = {255, 0, 0, 255}; // Red
const SDL_Color TEXT_COLOR = {0, 0, 0, 255}; // Black

struct Node {
    int x, y;
    std::string label;
};

struct Edge {
    int from, to;
    int weight;
};

void AdjustLineToCircle(int &x1, int &y1, int &x2, int &y2, int radius) {
    double angle = atan2(y2 - y1, x2 - x1);
    x2 -= radius * cos(angle);
    y2 -= radius * sin(angle);
}

void DrawArrow(SDL_Renderer *renderer, int x1, int y1, int x2, int y2) {
    const double ARROW_ANGLE = M_PI / 6;
    const double ARROW_LENGTH = 15.0;

    double angle = atan2(y2 - y1, x2 - x1);

    int arrowX1 = x2 - ARROW_LENGTH * cos(angle - ARROW_ANGLE);
    int arrowY1 = y2 - ARROW_LENGTH * sin(angle - ARROW_ANGLE);
    int arrowX2 = x2 - ARROW_LENGTH * cos(angle + ARROW_ANGLE);
    int arrowY2 = y2 - ARROW_LENGTH * sin(angle + ARROW_ANGLE);

    SDL_RenderDrawLine(renderer, x2, y2, arrowX1, arrowY1);
    SDL_RenderDrawLine(renderer, x2, y2, arrowX2, arrowY2);
}

void DrawNode(SDL_Renderer *renderer, TTF_Font *font, Node node) {
    SDL_SetRenderDrawColor(renderer, NODE_COLOR.r, NODE_COLOR.g, NODE_COLOR.b, NODE_COLOR.a);
    for (int w = -NODE_RADIUS; w <= NODE_RADIUS; w++) {
        for (int h = -NODE_RADIUS; h <= NODE_RADIUS; h++) {
            if (w * w + h * h <= NODE_RADIUS * NODE_RADIUS) {
                SDL_RenderDrawPoint(renderer, node.x + w, node.y + h);
            }
        }
    }

    SDL_Surface *textSurface = TTF_RenderText_Solid(font, node.label.c_str(), TEXT_COLOR);
    SDL_Texture *textTexture = SDL_CreateTextureFromSurface(renderer, textSurface);
    SDL_Rect textRect = {node.x - textSurface->w / 2, node.y - textSurface->h / 2, textSurface->w, textSurface->h};
    SDL_RenderCopy(renderer, textTexture, nullptr, &textRect);
    SDL_FreeSurface(textSurface);
    SDL_DestroyTexture(textTexture);
}

void DrawEdge(SDL_Renderer *renderer, TTF_Font *font, Node from, Node to, int weight) {
    SDL_SetRenderDrawColor(renderer, EDGE_COLOR.r, EDGE_COLOR.g, EDGE_COLOR.b, EDGE_COLOR.a);

    int x1 = from.x, y1 = from.y, x2 = to.x, y2 = to.y;
    AdjustLineToCircle(x1, y1, x2, y2, NODE_RADIUS);

    SDL_RenderDrawLine(renderer, x1, y1, x2, y2);

    DrawArrow(renderer, x1, y1, x2, y2);

    int midX = (x1 + x2) / 2;
    int midY = (y1 + y2) / 2;

    std::string weightStr = std::to_string(weight);
    SDL_Surface *textSurface = TTF_RenderText_Solid(font, weightStr.c_str(), TEXT_COLOR);
    SDL_Texture *textTexture = SDL_CreateTextureFromSurface(renderer, textSurface);
    SDL_Rect textRect = {midX - textSurface->w / 2, midY - textSurface->h / 2, textSurface->w, textSurface->h};
    SDL_RenderCopy(renderer, textTexture, nullptr, &textRect);
    SDL_FreeSurface(textSurface);
    SDL_DestroyTexture(textTexture);
}

int main(int argc, char *argv[]) {
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        std::cerr << "Failed to initialize SDL: " << SDL_GetError() << std::endl;
        return -1;
    }

    if (TTF_Init() < 0) {
        std::cerr << "Failed to initialize SDL_ttf: " << TTF_GetError() << std::endl;
        SDL_Quit();
        return -1;
    }

    TTF_Font *font = TTF_OpenFont("arial.ttf", 16);
    if (!font) {
        std::cerr << "Failed to load font: " << TTF_GetError() << std::endl;
        TTF_Quit();
        SDL_Quit();
        return -1;
    }

    SDL_Window *window = SDL_CreateWindow("Graf Transportasi", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
    if (!window) {
        std::cerr << "Failed to create window: " << SDL_GetError() << std::endl;
        TTF_CloseFont(font);
        TTF_Quit();
        SDL_Quit();
        return -1;
    }

    SDL_Renderer *renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer) {
        std::cerr << "Failed to create renderer: " << SDL_GetError() << std::endl;
        SDL_DestroyWindow(window);
        TTF_CloseFont(font);
        TTF_Quit();
        SDL_Quit();
        return -1;
    }

    std::vector<Node> nodes = {
        {150, 100, "PKU"}, {200, 250, "PLM"}, {450, 100, "KNO"},
        {400, 300, "CGK"}, {500, 400, "SRG"}, {600, 200, "SUB"}, {700, 400, "DPS"}, {100, 500, "UPG"}
    };

    std::vector<Edge> edges = {
        {0, 1, 75}, {0, 2, 60}, {1, 3, 120}, {2, 3, 105}, {3, 4, 90},
        {4, 5, 120}, {5, 6, 150}, {6, 7, 120}, {1, 7, 150}, {2, 5, 100}
    };

    bool isRunning = true;
    SDL_Event event;

    while (isRunning) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                isRunning = false;
            }
        }

        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
        SDL_RenderClear(renderer);

        for (auto &edge : edges) {
            DrawEdge(renderer, font, nodes[edge.from], nodes[edge.to], edge.weight);
        }

        for (auto &node : nodes) {
            DrawNode(renderer, font, node);
        }

        SDL_RenderPresent(renderer);
    }

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    TTF_CloseFont(font);
    TTF_Quit();
    SDL_Quit();

    return 0;
}
